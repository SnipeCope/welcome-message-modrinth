package com.snipecope.welcomemessagemod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v1.ClientCommandManager;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.ClickEvent;
import net.minecraft.text.HoverEvent;
import net.minecraft.text.LiteralText;
import net.minecraft.text.Style;
import net.minecraft.text.TextColor;
import net.minecraft.text.Text;

import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

/*
 * Last update: 30/12/2025
 * IMPORTANT; READ THIS!
 * 
 * Summary (if you dont want to read all of that):
 *   This mod stores local-only flags to remember if the welcome 
 *   message was already shown per world/server. No data is sent 
 *   anywhere.
 *
 * This mod uses Java Preferences ONLY to store:
 *  - Whether the welcome message is enabled or disabled
 *  - Whether the welcome message has already been shown
 *    for a specific world or server
 *
 * All data is stored LOCALLY on the player's computer.
 * Nothing is sent over the network.
 * No personal data, IPs, accounts, or gameplay data are collected.
 * 
 * We are NOT trying to get any type user data!
 *
 * The purpose of this storage is simply to ensure the welcome
 * message is shown only once per world or server, unless re-enabled
 * by the player via /welcomemessage true.
 * 
 * This storage is required for the mod to work. If you have any questions
 * regarding this, you can contact me through my Discord: @Snipecope.
 */

public class WelcomeMessageMod implements ClientModInitializer {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path CONFIG_FILE = FabricLoader.getInstance().getConfigDir().resolve("welcomemessagemod.json");
    private static ConfigData configData = new ConfigData();

    @Override
    public void onInitializeClient() {
        loadConfig();

        // Display welcome message if first time per world/server
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (!configData.enabled) return;
            client.execute(() -> showWelcomeMessageIfFirstTime(client, handler.getConnection().getAddress().toString()));
        });

        // Register /welcomemessage command
        ClientCommandManager.DISPATCHER.register(ClientCommandManager.literal("welcomemessage")
            .then(ClientCommandManager.literal("true")
                .executes(ctx -> {
                    configData.enabled = true;
                    saveConfig();
                    ctx.getSource().sendFeedback(new LiteralText("Welcome messages enabled."));
                    return 1;
                })
            )
            .then(ClientCommandManager.literal("false")
                .executes(ctx -> {
                    configData.enabled = false;
                    saveConfig();
                    ctx.getSource().sendFeedback(new LiteralText("Welcome messages disabled."));
                    return 1;
                })
            )
        );
    }

    private void showWelcomeMessageIfFirstTime(MinecraftClient client, String serverIdentifier) {
        String key = serverIdentifier.isEmpty() ? "singleplayer_" + client.world.getRegistryKey().getValue() : serverIdentifier;

        if (configData.shownServers.containsKey(key)) return;
        configData.shownServers.put(key, true);
        saveConfig();

        if (client.player == null) return;

        Text message = new LiteralText("Hello " + client.player.getName().getString() + "!")
                .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xFFFFFF)));

        Text body = new LiteralText(
                "Thank you for downloading our modpack! We really appreciate it.\n" +
                "If you find any bugs or have suggestions, contact me on Discord: @snipecope\n"
        ).setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xFFFFFF)));

        Text clickable = new LiteralText("Click here for more mods!")
                .setStyle(Style.EMPTY
                        .withColor(TextColor.fromRgb(0x0000FF))
                        .withUnderline(true)
                        .withClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, "https://modrinth.com/user/snipecope"))
                        .withHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new LiteralText("Go to my mods!")))
                );

        Text note = new LiteralText("(This message will be displayed only the first time you join this world or server. /welcomemessage false disables it globally.)")
                .setStyle(Style.EMPTY.withColor(TextColor.fromRgb(0xAAAAAA)));

        client.player.sendMessage(new LiteralText(""), false); // Blank line
        client.player.sendMessage(message, false);
        client.player.sendMessage(new LiteralText(""), false); // Blank line
        client.player.sendMessage(body, false);
        client.player.sendMessage(clickable, false);
        client.player.sendMessage(note, false);
        client.player.sendMessage(new LiteralText(""), false); // Blank line
    }

    private void loadConfig() {
        if (Files.exists(CONFIG_FILE)) {
            try {
                Type type = new TypeToken<ConfigData>() {}.getType();
                configData = GSON.fromJson(Files.readString(CONFIG_FILE), type);
            } catch (IOException e) {
                e.printStackTrace();
                configData = new ConfigData();
            }
        }
    }

    private void saveConfig() {
        try {
            Files.writeString(CONFIG_FILE, GSON.toJson(configData));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class ConfigData {
        boolean enabled = true;
        Map<String, Boolean> shownServers = new HashMap<>();
    }
}
